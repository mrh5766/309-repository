Vansh Pahuja
vp2350@rit.edu

Torus:
Was not able to figure out how to implement the vertical subdivisions.

Sphere:
Seems to be working properly but shape does inward after a certain point, could not figure out why it does that. 