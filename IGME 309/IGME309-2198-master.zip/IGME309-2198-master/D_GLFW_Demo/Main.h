/*--------------------------------------------------------------------------------------------------
This project was generated in 2013
--------------------------------------------------------------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include "Simplex\Simplex.h"
#include "GLFW\glfw3.h"

#endif //_MAIN_H

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/
