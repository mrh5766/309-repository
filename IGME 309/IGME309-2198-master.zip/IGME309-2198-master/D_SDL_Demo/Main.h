/*--------------------------------------------------------------------------------------------------
This project was generated in 2017
--------------------------------------------------------------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_

#define SDL_MAIN_HANDLED

#include "Simplex\Simplex.h"
#include "SDL\SDL.h"
#include "SDL\SDL_opengl.h"

#endif //_MAIN_H

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/