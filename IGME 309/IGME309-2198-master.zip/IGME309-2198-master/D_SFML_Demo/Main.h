/*--------------------------------------------------------------------------------------------------
This project was generated in 2013
--------------------------------------------------------------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_

#include "Simplex\Simplex.h"
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>

#endif //__MAIN_H_

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/