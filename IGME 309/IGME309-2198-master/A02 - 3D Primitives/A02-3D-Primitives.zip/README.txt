Michael Hrehocik
mrh5766@rit.edu

Sphere: One part of sphere does not show up at exactly 10 and 15 vertical subdivisions. My guess would be that it's a floating point error like someone mentioned on the discord.